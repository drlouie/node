var expect  = require('chai').expect;
var whoisQuery = require('../whois-query.npm');

describe('whoisQuery()', function(){
	it ('should return the same host we presented it',function(){
		//> 1. Arange
		var DomainNameToQuery = 'arin.net';

		//> 2. Act
		var queriedDomain = whoisQuery(DomainNameToQuery);

		//> 3. Assert
		expect(queriedDomain).to.equal(DomainNameToQuery);
	});
	it ('should not throw any exceptions even if no domain presented',function(){
		expect(whoisQuery).to.not.throw();
	});
});
