var expect  = require('chai').expect;
var portScan = require('../port-scanner.npm');

describe('portScan()', function(){
	it ('should return the same host we presented it',function(){
		//> 1. Arange
		var hostToScan = 'yahoo.com';

		//> 2. Act
		var scannedHost = portScan(hostToScan);

		//> 3. Assert
		expect(scannedHost).to.equal(hostToScan);
	});
	it ('should not throw any exceptions even if no host presented',function(){
		expect(portScan).to.not.throw();
	});
});
